package com.example.wishspheres;

import net.minecraftforge.common.ForgeConfigSpec;

public class Config {
    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();

    public static final ForgeConfigSpec.IntValue MIN_DISTANCE = B
            .comment("Distancia minima (bloques) desde el spawn a la que puede aparecer una esfera.")
            .defineInRange("minDistance", 300, 0, 1_000_000);
    public static final ForgeConfigSpec.IntValue MAX_DISTANCE = B
            .comment("Distancia maxima (bloques) desde el spawn a la que puede aparecer una esfera.")
            .defineInRange("maxDistance", 3000, 100, 1_000_000);
    public static final ForgeConfigSpec.BooleanValue GLOWING = B
            .comment("Las esferas brillan (se ven a traves de bloques) para poder encontrarlas.")
            .define("glowing", true);

    public static final ForgeConfigSpec.BooleanValue REDISTRIBUTE = B
            .comment("Tras conceder un deseo, las esferas se reparten de nuevo por el mundo (deseos ilimitados).")
            .define("redistributeAfterWish", true);

    public static final ForgeConfigSpec SPEC = B.build();
}
