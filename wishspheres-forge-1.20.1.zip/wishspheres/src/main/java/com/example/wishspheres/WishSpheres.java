package com.example.wishspheres;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(WishSpheres.MODID)
public class WishSpheres {
    public static final String MODID = "wishspheres";
    public static final int COUNT = 7;

    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final List<RegistryObject<Item>> SPHERES = new ArrayList<>();

    static {
        for (int i = 1; i <= COUNT; i++) {
            final int n = i;
            SPHERES.add(ITEMS.register("wish_sphere_" + n, () -> new WishSphereItem(n)));
        }
    }

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("wish_spheres", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.wishspheres"))
                    .icon(() -> new ItemStack(SPHERES.get(3).get()))
                    .displayItems((params, out) -> SPHERES.forEach(s -> out.accept(s.get())))
                    .build());

    public WishSpheres() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
        TABS.register(bus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, Config.SPEC);
        MinecraftForge.EVENT_BUS.register(new WishEvents());
    }
}
