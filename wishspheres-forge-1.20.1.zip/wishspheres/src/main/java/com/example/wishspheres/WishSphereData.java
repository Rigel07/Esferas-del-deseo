package com.example.wishspheres;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.saveddata.SavedData;

/** Guarda donde debe aparecer cada esfera y si ya fue colocada en el mundo. */
public class WishSphereData extends SavedData {
    public final int[] x = new int[WishSpheres.COUNT];
    public final int[] z = new int[WishSpheres.COUNT];
    public final boolean[] spawned = new boolean[WishSpheres.COUNT];

    public static WishSphereData get(ServerLevel overworld) {
        return overworld.getDataStorage().computeIfAbsent(WishSphereData::load, () -> create(overworld), "wishspheres");
    }

    private static WishSphereData create(ServerLevel level) {
        WishSphereData d = new WishSphereData();
        d.fill(level, RandomSource.create(level.getSeed() ^ 0x5DEECE66DL));
        return d;
    }

    /** Genera 7 posiciones nuevas y marca todas las esferas como pendientes de colocar. */
    public void regenerate(ServerLevel level) {
        fill(level, RandomSource.create(level.getSeed() ^ level.getGameTime() ^ System.nanoTime()));
    }

    private void fill(ServerLevel level, RandomSource r) {
        BlockPos c = level.getSharedSpawnPos();
        int min = Config.MIN_DISTANCE.get();
        int max = Math.max(min + 1, Config.MAX_DISTANCE.get());
        for (int i = 0; i < WishSpheres.COUNT; i++) {
            double ang = r.nextDouble() * Math.PI * 2;
            double dist = min + r.nextDouble() * (max - min);
            x[i] = c.getX() + (int) Math.round(Math.cos(ang) * dist);
            z[i] = c.getZ() + (int) Math.round(Math.sin(ang) * dist);
            spawned[i] = false;
        }
        setDirty();
    }

    public static WishSphereData load(CompoundTag tag) {
        WishSphereData d = new WishSphereData();
        int[] xs = tag.getIntArray("x");
        int[] zs = tag.getIntArray("z");
        byte[] sp = tag.getByteArray("spawned");
        for (int i = 0; i < WishSpheres.COUNT; i++) {
            if (i < xs.length) d.x[i] = xs[i];
            if (i < zs.length) d.z[i] = zs[i];
            if (i < sp.length) d.spawned[i] = sp[i] != 0;
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putIntArray("x", x);
        tag.putIntArray("z", z);
        byte[] sp = new byte[WishSpheres.COUNT];
        for (int i = 0; i < sp.length; i++) sp[i] = (byte) (spawned[i] ? 1 : 0);
        tag.putByteArray("spawned", sp);
        return tag;
    }
}
