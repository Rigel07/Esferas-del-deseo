package com.example.wishspheres;

import net.minecraft.commands.Commands;
import net.minecraft.core.SectionPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.item.ItemTossEvent;
import net.minecraftforge.event.entity.player.EntityItemPickupEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;

public class WishEvents {
    private static final String WISHING = "Wishing";
    private static final String PREV_MODE = "PrevMode";
    private static final String SAVED_INV = "SavedInv";

    // ---------------------------------------------------------------- spawn de esferas

    @SubscribeEvent
    public void onLevelTick(TickEvent.LevelTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != LogicalSide.SERVER) return;
        if (!(e.level instanceof ServerLevel level) || level.dimension() != Level.OVERWORLD) return;
        if (level.getGameTime() % 20 != 0) return;

        WishSphereData d = WishSphereData.get(level);
        for (int i = 0; i < WishSpheres.COUNT; i++) {
            if (d.spawned[i]) continue;
            int cx = SectionPos.blockToSectionCoord(d.x[i]);
            int cz = SectionPos.blockToSectionCoord(d.z[i]);
            LevelChunk chunk = level.getChunkSource().getChunkNow(cx, cz);
            if (chunk == null) continue; // el chunk aun no esta cargado: se coloca al explorarlo
            spawnSphere(level, d, i);
        }
    }

    private static void spawnSphere(ServerLevel level, WishSphereData d, int i) {
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, d.x[i], d.z[i]);
        ItemEntity ie = new ItemEntity(level, d.x[i] + 0.5, y + 0.5, d.z[i] + 0.5,
                new ItemStack(WishSpheres.SPHERES.get(i).get()));
        ie.setUnlimitedLifetime();
        ie.setInvulnerable(true);
        ie.setDeltaMovement(Vec3.ZERO);
        if (Config.GLOWING.get()) ie.setGlowingTag(true);
        level.addFreshEntity(ie);
        d.spawned[i] = true;
        d.setDirty();
    }

    // ---------------------------------------------------------------- logica del deseo

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != LogicalSide.SERVER) return;
        if (!(e.player instanceof ServerPlayer p)) return;

        CompoundTag data = persisted(p);
        if (data.getBoolean(WISHING)) {
            checkWishTaken(p, data);
        } else if (p.tickCount % 10 == 0 && !p.isSpectator()) {
            tryStartWish(p, data);
        }
    }

    private static boolean[] scan(Inventory inv) {
        boolean[] has = new boolean[WishSpheres.COUNT];
        for (ItemStack s : inv.items) mark(s, has);
        for (ItemStack s : inv.offhand) mark(s, has);
        return has;
    }

    private static void mark(ItemStack s, boolean[] has) {
        if (s.getItem() instanceof WishSphereItem w) has[w.getNumber() - 1] = true;
    }

    private static void removeOne(Inventory inv, int number) {
        for (ItemStack s : inv.items) {
            if (s.getItem() instanceof WishSphereItem w && w.getNumber() == number) { s.shrink(1); return; }
        }
        for (ItemStack s : inv.offhand) {
            if (s.getItem() instanceof WishSphereItem w && w.getNumber() == number) { s.shrink(1); return; }
        }
    }

    private static void tryStartWish(ServerPlayer p, CompoundTag data) {
        Inventory inv = p.getInventory();
        for (boolean b : scan(inv)) if (!b) return;

        // Consumir las 7 esferas
        for (int n = 1; n <= WishSpheres.COUNT; n++) removeOne(inv, n);

        // Guardar inventario y modo de juego, dejar el inventario vacio
        ListTag saved = new ListTag();
        inv.save(saved);
        data.put(SAVED_INV, saved);
        data.putInt(PREV_MODE, p.gameMode.getGameModeForPlayer().getId());
        data.putBoolean(WISHING, true);
        inv.clearContent();

        p.setGameMode(GameType.CREATIVE);
        p.inventoryMenu.broadcastChanges();

        ServerLevel level = p.serverLevel();
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt != null) {
            bolt.moveTo(p.position());
            bolt.setVisualOnly(true);
            level.addFreshEntity(bolt);
        }
        p.displayClientMessage(Component.translatable("message.wishspheres.start"), false);
    }

    private static void checkWishTaken(ServerPlayer p, CompoundTag data) {
        Inventory inv = p.getInventory();
        ItemStack wished = ItemStack.EMPTY;

        search:
        for (var list : java.util.List.of(inv.items, inv.armor, inv.offhand)) {
            for (ItemStack s : list) {
                if (!s.isEmpty()) {
                    wished = s.copy();
                    wished.setCount(1); // solo UNA unidad, aunque haya cogido un stack
                    break search;
                }
            }
        }
        if (wished.isEmpty()) return;

        // Restaurar inventario original y modo de juego previo
        inv.clearContent();
        inv.load(data.getList(SAVED_INV, 10));
        GameType prev = GameType.byId(data.getInt(PREV_MODE));
        data.remove(WISHING);
        data.remove(SAVED_INV);
        data.remove(PREV_MODE);
        p.setGameMode(prev);

        if (!inv.add(wished)) p.drop(wished, false);
        p.inventoryMenu.broadcastChanges();
        p.containerMenu.broadcastChanges();

        p.level().playSound(null, p.blockPosition(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.PLAYERS, 1f, 1f);
        p.displayClientMessage(Component.translatable("message.wishspheres.end"), false);

        // Las esferas se dispersan de nuevo por el mundo
        if (Config.REDISTRIBUTE.get() && p.getServer() != null) {
            ServerLevel overworld = p.getServer().overworld();
            WishSphereData.get(overworld).regenerate(overworld);
            p.getServer().getPlayerList().broadcastSystemMessage(
                    Component.translatable("message.wishspheres.scatter"), false);
        }
    }

    // ---------------------------------------------------------------- utilidades / proteccion

    private static CompoundTag persisted(Player p) {
        CompoundTag root = p.getPersistentData();
        if (!root.contains(Player.PERSISTED_NBT_TAG, 10)) root.put(Player.PERSISTED_NBT_TAG, new CompoundTag());
        return root.getCompound(Player.PERSISTED_NBT_TAG);
    }

    private static boolean isWishing(Player p) {
        return persisted(p).getBoolean(WISHING);
    }

    @SubscribeEvent
    public void onToss(ItemTossEvent e) {
        if (isWishing(e.getPlayer())) e.setCanceled(true);
    }

    @SubscribeEvent
    public void onPickup(EntityItemPickupEvent e) {
        if (isWishing(e.getEntity())) e.setCanceled(true);
    }

    @SubscribeEvent
    public void onClone(PlayerEvent.Clone e) {
        CompoundTag old = e.getOriginal().getPersistentData();
        if (old.contains(Player.PERSISTED_NBT_TAG, 10)) {
            e.getEntity().getPersistentData().put(Player.PERSISTED_NBT_TAG, old.getCompound(Player.PERSISTED_NBT_TAG).copy());
        }
    }

    // ---------------------------------------------------------------- comando de ayuda (OP)

    @SubscribeEvent
    public void onCommands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("wishspheres")
                .requires(s -> s.hasPermission(2))
                .then(Commands.literal("locate").executes(ctx -> {
                    ServerLevel ow = ctx.getSource().getServer().overworld();
                    WishSphereData d = WishSphereData.get(ow);
                    for (int i = 0; i < WishSpheres.COUNT; i++) {
                        final String msg = "Esfera " + (i + 1) + ": X=" + d.x[i] + " Z=" + d.z[i]
                                + (d.spawned[i] ? " (colocada)" : " (pendiente: explora esa zona)");
                        ctx.getSource().sendSuccess(() -> Component.literal(msg), false);
                    }
                    return WishSpheres.COUNT;
                })));
    }
}
