# Esferas del Deseo - Forge 1.20.1 (47.x)

- 7 items: "Esfera del Deseo 1" ... "Esfera del Deseo 7".
- Cada esfera aparece (brillante) en una posicion aleatoria entre `minDistance` y `maxDistance`
  bloques del spawn, cuando ese chunk se carga/explora. Son indestructibles y no desaparecen.
- Al tener las 7 en el inventario se consumen, se guarda tu inventario y modo de juego,
  y pasas a creativo con el inventario vacio. Coges UN objeto (solo se te da 1 unidad):
  recuperas tu inventario, tu modo anterior y recibes ese objeto.
- Mientras eliges no puedes tirar ni recoger objetos.
- Tras cada deseo las esferas se reparten de nuevo (desactivable con `redistributeAfterWish`).
- `/wishspheres locate` (OP) muestra las coordenadas para pruebas.
- Config: `config/wishspheres-common.toml`.

## Compilar
Copia `src/`, `build.gradle` y `settings.gradle` sobre el MDK oficial de Forge 1.20.1
(o ejecuta `gradle wrapper` aqui), y luego `./gradlew build`. El jar queda en `build/libs/`.
